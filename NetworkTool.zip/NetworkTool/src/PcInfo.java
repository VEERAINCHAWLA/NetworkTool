
public class PcInfo {

    String ip, pcname;

    boolean cb;
    PcInfo(String ip, String pcname) {

        this.ip = ip;
        this.pcname = pcname;

    }

    public PcInfo(String ip, String pcname, boolean cb) {
        this.ip = ip;
        this.pcname = pcname;
        this.cb = cb;
    }
}
