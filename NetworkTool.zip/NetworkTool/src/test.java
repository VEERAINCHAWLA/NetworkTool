
import java.io.DataInputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class test {

    public static void main(String[] args) throws IOException, InterruptedException {
        int c = 1;
        for (int i = 0; i < 17; i++) {
            Thread t[] = new Thread[15];
            for (int j = 0; j < 15; j++) {
                job obj = new job(c);
                t[j] = new Thread(obj);
                t[j].start();
                c++;
            }
            for (int j = 0; j < 15; j++) {
                t[j].join();

            }

            System.out.println(i + " slot implemented");
        }
    }

}

class job implements Runnable {

    int ip;

    job(int ip) {
        this.ip = ip;
    }

    public void run() {

        try {

            Process p = Runtime.getRuntime().exec("ping " + credentials.range + ip);
            DataInputStream dis = new DataInputStream(p.getInputStream());
            int count = 0;
            while (true) {
                String s = dis.readLine();
                if (s == null) {
                    break;
                } else if (s.contains("TTL"));
                {
                    count++;
                }
                // System.out.println(s);

            }

            if (count == 4) {
                System.out.println("172.16.2." + ip + " connected");
            } 
        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }
}
