
import java.awt.Desktop;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class Explore extends javax.swing.JFrame {

    ArrayList<PcInfo> al2;
    String request;

    public Explore(ArrayList<PcInfo> al2) {
        initComponents();

        int width = Toolkit.getDefaultToolkit().getScreenSize().width;
        int height = Toolkit.getDefaultToolkit().getScreenSize().height;

        setSize(width, height);
        this.al2 = al2;

        jLabel1.setText(al2.size() + " systems connected");

        SinglePanel[] sp = new SinglePanel[al2.size()];
        int x = 30;
        int y = 50;
        for (int i = 0; i < al2.size(); i++) {

            sp[i] = new SinglePanel();
            sp[i].setBounds(x, y, 180, 250);
            sp[i].lb2.setText(al2.get(i).ip);
            final String sip = al2.get(i).ip;
            sp[i].lb3.setText(al2.get(i).pcname);

            MainPanel.add(sp[i]);
            sp[i].addMouseListener(new MouseAdapter() {

                public void mouseClicked(MouseEvent e) {

                    if (e.getClickCount() == 2) {

                        request = "Send Configuration";
                        client obj = new client(sip);
                        Thread t3 = new Thread(obj);
                        t3.start();

                    } else {
                        if (e.getButton() == 3) {

                            PopupMenu pop = new PopupMenu();

                            MenuItem mi1 = new MenuItem("Shutdown");
                            mi1.addActionListener(new ActionListener() {

                                @Override
                                public void actionPerformed(ActionEvent e) {

                                    request = "Shutdown";
                                    client obj = new client(sip);
                                    Thread t1 = new Thread(obj);
                                    t1.start();

                                }
                            });

                            MenuItem mi2 = new MenuItem("Restart");

                            mi2.addActionListener(new ActionListener() {

                                @Override
                                public void actionPerformed(ActionEvent e) {

                                    request = "Restart";
                                    client obj = new client(sip);
                                    Thread t1 = new Thread(obj);
                                    t1.start();

                                }
                            });
                            MenuItem mi3 = new MenuItem("Log Off");
                            mi3.addActionListener(new ActionListener() {

                                @Override
                                public void actionPerformed(ActionEvent e) {

                                    request = "Log off";
                                    client obj = new client(sip);
                                    Thread t1 = new Thread(obj);
                                    t1.start();

                                }
                            });
                            MenuItem mi4 = new MenuItem("View Screen");
                            mi4.addActionListener(new ActionListener() {

                                @Override
                                public void actionPerformed(ActionEvent e) {

                                    request = "view screen";
                                    client obj = new client(sip);
                                    Thread t1 = new Thread(obj);
                                    t1.start();

                                }
                            });
                            pop.add(mi1);
                            pop.addSeparator();
                            pop.add(mi2);
                            pop.addSeparator();
                            pop.add(mi3);
                            pop.addSeparator();
                            pop.add(mi4);

                            add(pop);
                            pop.show(Explore.this, e.getXOnScreen(), e.getYOnScreen());

                        }

                    }

                }

            });

            if (x < 800) {

                x = x + 190;

            } else {
                x = 30;
                y = y + 260;
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        MainPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        lb_ip = new javax.swing.JLabel();
        lb_pcname = new javax.swing.JLabel();
        lb_os = new javax.swing.JLabel();
        lb_num_of_processor = new javax.swing.JLabel();
        lb_ram = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        MainPanel.setBackground(new java.awt.Color(0, 102, 102));
        MainPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MainPanel.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Arial", 2, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        MainPanel.add(jLabel1);
        jLabel1.setBounds(20, 20, 430, 30);

        getContentPane().add(MainPanel);
        MainPanel.setBounds(0, 0, 1070, 780);

        jPanel2.setBackground(new java.awt.Color(255, 255, 153));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("IP ADDRESS");
        jLabel2.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jPanel2.add(jLabel2);
        jLabel2.setBounds(10, 160, 80, 30);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("PC NAME");
        jPanel2.add(jLabel3);
        jLabel3.setBounds(10, 230, 90, 40);

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("OPERATING SYSTEM");
        jPanel2.add(jLabel4);
        jLabel4.setBounds(10, 310, 140, 50);

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("NO OF PROCESSORS");
        jPanel2.add(jLabel5);
        jLabel5.setBounds(10, 400, 140, 60);

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("RAM");
        jPanel2.add(jLabel6);
        jLabel6.setBounds(10, 510, 120, 40);

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pics/pcpic.jpg"))); // NOI18N
        jPanel2.add(jLabel8);
        jLabel8.setBounds(100, 20, 130, 110);
        jPanel2.add(lb_ip);
        lb_ip.setBounds(120, 160, 110, 30);
        jPanel2.add(lb_pcname);
        lb_pcname.setBounds(130, 230, 120, 30);
        jPanel2.add(lb_os);
        lb_os.setBounds(160, 320, 130, 30);
        jPanel2.add(lb_num_of_processor);
        lb_num_of_processor.setBounds(160, 410, 120, 40);
        jPanel2.add(lb_ram);
        lb_ram.setBounds(150, 520, 90, 30);

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButton1.setText("Export to Excel");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1);
        jButton1.setBounds(40, 620, 210, 40);

        getContentPane().add(jPanel2);
        jPanel2.setBounds(1070, 0, 300, 780);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            // TODO add your handlinclass Excel implements Runnable{

            
            File f1 = new File(System.getProperty("user.home") + "\\Controller Files");
            if (!f1.exists()) {
                f1.mkdir();
            }
            File f = new File(System.getProperty("user.home") + "\\Controller Files\\" + lb_pcname.getText() + ".xls");
            HSSFWorkbook workbook = new HSSFWorkbook();
            HSSFSheet sheet = workbook.createSheet("FirstSheet");
            
            HSSFRow row0 = sheet.createRow((short) 0);
            row0.createCell(0).setCellValue("IP Address : ");
            row0.createCell(4).setCellValue(lb_ip.getText());
           
            
            
            HSSFRow row1 = sheet.createRow((short) 1);
            row1.createCell(0).setCellValue("PC Name : ");
            row1.createCell(4).setCellValue(lb_pcname.getText());
           
                       
            HSSFRow row2 = sheet.createRow((short) 2);
            row2.createCell(0).setCellValue("OS Name : ");
            row2.createCell(4).setCellValue(lb_os.getText());  
          
           
            HSSFRow row3 = sheet.createRow((short) 3);
            row3.createCell(0).setCellValue("No of Cores");
            row3.createCell(4).setCellValue(lb_num_of_processor.getText()); 
           

            HSSFRow row4 = sheet.createRow((short) 4);
            row4.createCell(0).setCellValue("RAM Size");
            row4.createCell(4).setCellValue(lb_ram.getText());
          

            FileOutputStream fileOut = new FileOutputStream(f);
            workbook.write(fileOut);
            fileOut.close();
            //System.out.println("Your excel file has been generated!");
            int r = JOptionPane.showConfirmDialog(rootPane, "Excel File has been generated!!!!!!!\n Do you want to open? ");
            if (r == JOptionPane.YES_OPTION) {
                Desktop.getDesktop().open(f);
            }
        } catch (IOException ex) {
            Logger.getLogger(Explore.class.getName()).log(Level.SEVERE, null, ex);
        }

        
    
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Explore.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Explore.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Explore.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Explore.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                //new Explore().setVisible(true);
            }
        });
    }

    class client implements Runnable {

        String ip;

        client(String ip) {

            this.ip = ip;
        }

        @Override

        public void run() {
            try {
                System.out.println("ip :" + ip);
                Socket sock = new Socket(ip, 8000);
                System.out.println("Connected to network");

                DataInputStream dis = new DataInputStream(sock.getInputStream());
                DataOutputStream dos = new DataOutputStream(sock.getOutputStream());

                if (request.equals("Send Configuration")) {
                    System.out.println("hello...........");
                    dos.writeBytes("Send Configuration\r\n");
                    String ip = dis.readLine();
                    String pcName = dis.readLine();
                    String nameOs = dis.readLine();
                    String cores = dis.readLine();
                    String memorySize = dis.readLine();

                    System.out.println(ip + "-----------");
                    lb_ip.setText(ip);
                    lb_pcname.setText(pcName);
                    lb_os.setText(nameOs);
                    lb_num_of_processor.setText(cores + "");
                    lb_ram.setText(Math.round(Long.parseLong(memorySize) / (1024.0 * 1024 * 1024)) + "");

                } else if (request.equals("Shutdown")) {

                    dos.writeBytes("Shutdown\r\n");

                } else if (request.equals("Restart")) {

                    dos.writeBytes("Restart\r\n");

                } else if (request.equals("Log off")) {

                    dos.writeBytes("Logoff\r\n");

                } else if (request.equals("view screen")) {

                    dos.writeBytes("view screen\r\n");
                    int sw = dis.readInt();
                    int sh = dis.readInt();

                    int mw = Toolkit.getDefaultToolkit().getScreenSize().width;
                    int mh = Toolkit.getDefaultToolkit().getScreenSize().height;

                    ViewScreen obj = new ViewScreen(ip);
                    obj.setSize(mw, mh);
                    obj.jsp.setSize(mw, mh);
                    obj.lb1.setSize(sw, sh);
                    obj.setVisible(true);

                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel MainPanel;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lb_ip;
    private javax.swing.JLabel lb_num_of_processor;
    private javax.swing.JLabel lb_os;
    private javax.swing.JLabel lb_pcname;
    private javax.swing.JLabel lb_ram;
    // End of variables declaration//GEN-END:variables
}
