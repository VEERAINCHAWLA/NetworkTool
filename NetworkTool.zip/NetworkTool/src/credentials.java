public class credentials{
    
    static String range = "";
    
}