
import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import static java.awt.image.ImageObserver.WIDTH;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

public class ServerFrame extends javax.swing.JFrame {

    public ServerFrame() {
        initComponents();
        setVisible(true);
        setSize(415, 320);
        
        
        int width = Toolkit.getDefaultToolkit().getScreenSize().width;
        int height = Toolkit.getDefaultToolkit().getScreenSize().height;
        
        int x = (width/2) - (this.getWidth()/2);
        int y = (height/2) - (this.getHeight()/2);
        
        setLocation(x, y);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        jPanel1.setLayout(null);

        jButton1.setBackground(new java.awt.Color(0, 51, 153));
        jButton1.setFont(new java.awt.Font("Arial", 3, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 51, 153));
        jButton1.setText("Start Server");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(140, 140, 130, 30);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/serverpic.jpg"))); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, 0, 400, 300);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 400, 300);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        ChatServer obj = new ChatServer();
        Thread t = new Thread(obj);
        t.start();

        //photo server
        PhotoServer obj1 = new PhotoServer();
        Thread t2 = new Thread(obj1);
        t2.start();

    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ServerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ServerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ServerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ServerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ServerFrame().setVisible(true);
            }
        });
    }

    class ChatServer implements Runnable {

        public void run() {
            try {
                ServerSocket sersock = new ServerSocket(8000);
                System.out.println("Server Started at port 8000");
                while (true) {
                    Socket sock = sersock.accept();

                    System.out.println("Connection Accepted from Client");

                    ClientHandler obj = new ClientHandler(sock);

                    Thread t = new Thread(obj);
                    t.start();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        class ClientHandler implements Runnable {

            Socket sock;

            ClientHandler(Socket sock) {

                this.sock = sock;
            }

            @Override
            public void run() {
                try {

                    DataInputStream dis = new DataInputStream(sock.getInputStream());
                    DataOutputStream dos = new DataOutputStream(sock.getOutputStream());
                    while (true) {
                        
                        String s = dis.readLine();
                        if (s.equals("hello server")) {
                            dos.writeBytes("hello client\r\n");
                            System.out.println(s);
                            break;

                        } else if (s.equals("Send Configuration")) {

                            InetAddress ip;
                            try {

                                ip = InetAddress.getLocalHost();
                                String pcName = ip.getHostName();
                                System.out.println("Current IP address : " + ip.getHostAddress());
                                String nameOS = System.getProperty("os.name");
                                System.out.println("Operating system Name=>" + nameOS);
                                int cores = Runtime.getRuntime().availableProcessors();
                                long memorySize = ((com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean()).getTotalPhysicalMemorySize();
                                dos.writeBytes(ip + "\r\n");
                                dos.writeBytes(pcName + "\r\n");
                                dos.writeBytes(nameOS + "\r\n");
                                dos.writeBytes(cores + "\r\n");

                                dos.writeBytes(memorySize + "\r\n");

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        } else if (s.equals("Shutdown")) {

                            Runtime runtime = Runtime.getRuntime();
                            Process proc = runtime.exec("shutdown -s -t 0");
                            System.exit(0);

                        } else if (s.equals("Restart")) {

                            Runtime runtime = Runtime.getRuntime();

                            Process proc = runtime.exec("shutdown -r");
                            System.exit(0);
                        } else if (s.equals("Logoff")) {
                            Runtime runtime = Runtime.getRuntime();

                            Process proc = runtime.exec("shutdown -l");
                            System.exit(0);
                        } else if (s.equals("view screen")) {

                            int width = Toolkit.getDefaultToolkit().getScreenSize().width;
                            int height = Toolkit.getDefaultToolkit().getScreenSize().height;

                            dos.writeInt(width);
                            dos.writeInt(height);

                        } else if (s.equals("mouse moved")) {
                            int x = dis.readInt();
                            int y = dis.readInt();
                            Robot rb = new Robot();
                            rb.mouseMove(x, y);

                        } else if (s.equals("mouse dragged")) {
                            int Button = dis.readInt();

                            int x = dis.readInt();
                            int y = dis.readInt();
                            Robot rb = new Robot();
                          rb.mousePress(MouseEvent.BUTTON1_MASK);
                             rb.mouseMove(x, y);

                        } else if (s.equals("mouse released")) {

                            int Button = dis.readInt();

                            Robot rb = new Robot();

                            if (Button == 1) {
                                rb.mouseRelease(MouseEvent.BUTTON1_MASK);
                            } else if (Button == 2) {
                                rb.mouseRelease(MouseEvent.BUTTON2_MASK);
                            } else {
                                rb.mouseRelease(MouseEvent.BUTTON3_MASK);
                            }

                        }
                          else if(s.equals("mouse clicked"))
                        {
                            int button = dis.readInt();
                            int x = dis.readInt();
                            int y = dis.readInt();
                            
                            Robot rb = new Robot();
                            rb.mouseMove(x, y);
                             if (button == 1) {
                                 rb.mousePress(MouseEvent.BUTTON1_MASK);
                                 rb.mouseRelease(MouseEvent.BUTTON1_MASK);
                             }
                             else if(button==2)
                             {
                                 rb.mousePress(MouseEvent.BUTTON2_MASK);
                                 rb.mouseRelease(MouseEvent.BUTTON2_MASK);
                             }
                             else
                             {
                                 rb.mousePress(MouseEvent.BUTTON3_MASK);
                                 rb.mouseRelease(MouseEvent.BUTTON3_MASK);
                             }
                            
                        }
                          else if(s.equals("key pressed")){
                              
                              int code = dis.readInt();
                              Robot rb = new Robot();
                              rb.keyPress(code);                                                                                          
                              
                          }
                          else if(s.equals("key released")){
                              
                              int code = dis.readInt();
                              Robot rb = new Robot();                              
                              rb.keyRelease(code);
                              
                          }
                          else if(s.equals("double click"))
                          {
                              Robot rb = new Robot();
                              rb.mousePress(MouseEvent.BUTTON1_MASK);
                              rb.mouseRelease(MouseEvent.BUTTON1_MASK);
                              rb.mousePress(MouseEvent.BUTTON1_MASK);
                              rb.mouseRelease(MouseEvent.BUTTON1_MASK);
                          }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    class PhotoServer implements Runnable {

        public void run() {
            try {
                ServerSocket photosersock = new ServerSocket(7000);
                System.out.println("Photo Server Started at port 7000");
                while (true) {
                    Socket photosock = photosersock.accept();

                    System.out.println("Connection Accepted from Client");

                    PhotoClientHandler obj = new PhotoClientHandler(photosock);

                    Thread t = new Thread(obj);
                    t.start();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        class PhotoClientHandler implements Runnable {

            Socket photosock;

            PhotoClientHandler(Socket photosock) {

                this.photosock = photosock;
            }

            @Override
            public void run() {
                try {

                    DataInputStream photodis = new DataInputStream(photosock.getInputStream());
                    DataOutputStream photodos = new DataOutputStream(photosock.getOutputStream());
                    while (true) {

                        String s = photodis.readLine();

                        try {
//                            Thread.sleep(120);
                            Robot R = new Robot();

                            // It saves screenshot to desired path
                            String path = "Shot.jpg";

                            // Used to get ScreenSize and capture image
                            Rectangle capture
                                    = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
                            BufferedImage Image = R.createScreenCapture(capture);
                            ImageIO.write(Image, "jpg", new File(path));
                            System.out.println("Screenshot saved");

                            File f = new File("Shot.jpg");
                            FileInputStream fis = new FileInputStream(f);
                            long len = f.length();
                            photodos.writeLong(len);
                            byte b[] = new byte[1000];
                            int count = 0;
                            while (true) {
                                int r = fis.read(b, 0, 1000);
                                count = count + r;
                                photodos.write(b, 0, r);
                                if (count == len) {

                                    break;

                                }
                            }
                            String msg = photodis.readLine();
                            System.out.println(msg);

                            Thread.sleep(500);
                        } catch (AWTException | IOException | InterruptedException ex) {
                            System.out.println(ex);
                        }

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

        }

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
