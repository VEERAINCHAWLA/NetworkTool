
import java.awt.Toolkit;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;

public class MainController extends javax.swing.JFrame {

    ArrayList<String> al = new ArrayList<>();
    ArrayList<PcInfo> al2 = new ArrayList<>();
    mytablemodel tm;
    mytablemodel1 tm2;

    public MainController() {
        initComponents();

        setSize(515, 470);
        tm = new mytablemodel();
        tbname.setModel(tm);

        tm2 = new mytablemodel1();
        tbname1.setModel(tm2);
        
        int width = Toolkit.getDefaultToolkit().getScreenSize().width;
        int height = Toolkit.getDefaultToolkit().getScreenSize().height;
        
        int w = width/2 - (this.getWidth()/2);
        int h = height/2 - (this.getHeight()/2);
        setLocation(w, h);

    }

    class mytablemodel extends AbstractTableModel {

        String names[] = {"Ip Address "};

        @Override
        public String getColumnName(int column) {
            return names[column];
        }

        @Override
        public int getRowCount() {
            return al.size();
        }

        @Override
        public int getColumnCount() {

            return 1;
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {

            return al.get(rowIndex);
        }

    }

    class mytablemodel1 extends AbstractTableModel {
        
        String names[] = {"IP", "PCName"};
        @Override
        public String getColumnName(int column){
            return names[column];
        }
     
        @Override
        public int getRowCount() {
            return al2.size();
        }

        @Override
        public int getColumnCount() {
            return 2;
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
       PcInfo pc = al2.get(rowIndex);
       if(columnIndex == 0){
           
           return pc.ip;
       }
       else {
           
           return pc.pcname;
       } 
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        ss = new javax.swing.JButton();
        lbcount = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbname = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbname1 = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(255, 255, 153));
        jPanel2.setLayout(null);

        ss.setBackground(new java.awt.Color(255, 255, 255));
        ss.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        ss.setText("Detect");
        ss.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ssActionPerformed(evt);
            }
        });
        jPanel2.add(ss);
        ss.setBounds(20, 20, 170, 40);
        jPanel2.add(lbcount);
        lbcount.setBounds(40, 60, 120, 20);

        tbname.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        tbname.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null},
                {null},
                {null},
                {null}
            },
            new String [] {
                "Title 1"
            }
        ));
        jScrollPane1.setViewportView(tbname);

        jPanel2.add(jScrollPane1);
        jScrollPane1.setBounds(20, 90, 170, 190);

        jLabel1.setFont(new java.awt.Font("Arial", 2, 14)); // NOI18N
        jLabel1.setText("Click on Detect to get IP");
        jPanel2.add(jLabel1);
        jLabel1.setBounds(10, 320, 190, 30);

        jLabel2.setFont(new java.awt.Font("Arial", 2, 14)); // NOI18N
        jLabel2.setText("of the Computers in the Network");
        jPanel2.add(jLabel2);
        jLabel2.setBounds(10, 350, 210, 30);

        jPanel1.add(jPanel2);
        jPanel2.setBounds(10, 10, 220, 410);

        jPanel3.setBackground(new java.awt.Color(255, 255, 153));
        jPanel3.setLayout(null);

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jButton1.setText("Filter");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton1);
        jButton1.setBounds(20, 20, 210, 40);

        tbname1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Title 1", "Title 2"
            }
        ));
        jScrollPane2.setViewportView(tbname1);

        jPanel3.add(jScrollPane2);
        jScrollPane2.setBounds(20, 90, 210, 190);

        jButton2.setBackground(new java.awt.Color(255, 255, 255));
        jButton2.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jButton2.setText("Explore");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton2);
        jButton2.setBounds(20, 290, 210, 40);

        jButton3.setBackground(new java.awt.Color(255, 255, 255));
        jButton3.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jButton3.setText("compare");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton3);
        jButton3.setBounds(20, 340, 210, 40);

        jPanel1.add(jPanel3);
        jPanel3.setBounds(240, 10, 250, 410);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 520, 480);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ssActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ssActionPerformed
        String input = JOptionPane.showInputDialog("Input the range of your Network!!");
        credentials.range = input+".";
        
        Detect obj = new Detect();
        Thread t = new Thread(obj);
        t.start();


    }//GEN-LAST:event_ssActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        for (int i = 0; i < al.size(); i++) {

            client obj = new client(al.get(i));
            System.out.println(al.get(i));
            Thread t1 = new Thread(obj);
            t1.start();
        }
// TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
      Compare obj = new Compare(al2);
        obj.setVisible(true);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
Explore obj = new Explore(al2);
        obj.setVisible(true);






// TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    public static void main(String args[]) {

        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainController.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainController.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainController.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainController.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainController().setVisible(true);
            }
        });
    }

    class client implements Runnable {

        String ip;

        client(String ip) {

            this.ip = ip;
        }

        @Override

        public void run() {
            try {
                System.out.println("ip :"+ip);
                Socket sock = new Socket(ip, 8000);
                System.out.println("Connected to network");

                DataInputStream dis = new DataInputStream(sock.getInputStream());
                DataOutputStream dos = new DataOutputStream(sock.getOutputStream());
                
                dos.writeBytes("hello server\r\n");
                              
                String s = dis.readLine();
                System.out.println(s);
                String pcname = sock.getInetAddress().getHostName();
                al2.add(new PcInfo(ip, pcname));
                tm2.fireTableDataChanged();
                
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lbcount;
    private javax.swing.JButton ss;
    private javax.swing.JTable tbname;
    private javax.swing.JTable tbname1;
    // End of variables declaration//GEN-END:variables
class job implements Runnable {

        int ip;

        job(int ip) {
            this.ip = ip;
        }

        public void run() {

            try {

                Process p = Runtime.getRuntime().exec("ping " + credentials.range + ip);
                DataInputStream dis = new DataInputStream(p.getInputStream());
                int count = 0;
                while (true) {
                    String s = dis.readLine();
                    if (s == null) {
                        break;
                    } else if (s.contains("TTL")) {
                        count++;
                    }
                    // System.out.println(s);

                }

                System.out.println(credentials.range + ip);
                if (count == 4) {
                    System.out.println(credentials.range + ip + " connected");
                    al.add(credentials.range + ip);

                    tm.fireTableDataChanged();
                    lbcount.setText(al.size() + "system connected");
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }

        }

    }

    class Detect implements Runnable {

        @Override
        public void run() {
            int c = 1;
            for (int i = 0; i < 17; i++) {
              Thread t[] = new Thread[15];
                for (int j = 0; j < 15; j++) {
                    job obj = new job(c);
                    t[j] = new Thread(obj);
                    t[j].start();
                    c++;
                }
 for (int j = 0; j < 15; j++) {
                    try {
                        t[j].join();
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MainController.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }

                System.out.println(i + " slot implemented");
            }
            
//            for (int i = 50; i < 225; i++) {
//                job obj = new job(i);
//                Thread t = new Thread(obj);
//                t.start();
//            }
        }

    }

}
